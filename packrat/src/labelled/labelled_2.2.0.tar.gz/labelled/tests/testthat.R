library(testthat)
library(labelled)
test_check("labelled")
